#!/bin/python3

__all__ = ['cmdline', 'parse_and_run']

from autocall.parser import cmdline as cmdline 
from autocall.parser import parse_run as parse_and_run
